<?php

return array(
    //'配置项'=>'配置值'
    'resource_path' => '/Public/M/',
    'mobile_daily_request_amount'=>10
);
