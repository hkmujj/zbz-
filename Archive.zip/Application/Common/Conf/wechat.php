<?php
return array(
        /* 公众号设置 */
        'appid'=>'wxefd54d4bbcc42db5',
        'appsecret'=>'0cf4f04f27a35b24c6f86cdbee887390',
    );