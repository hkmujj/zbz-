<?php

namespace Admin\Controller;

use Think\Controller;

class ShoppingListController extends CommonController {

 

}
